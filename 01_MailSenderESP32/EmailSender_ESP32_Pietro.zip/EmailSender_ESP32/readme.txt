O código tem como função conectar o ESP32 a uma rede Wi-Fi, realizar leituras analógicas de tensão e enviar automaticamente um e-mail em formato HTML com os valores medidos.


